import json
import os
from types import SimpleNamespace


class FieldObjectIterator:
    """
    Allow for-in iteration of a known set of fields of an arbitrary
    listing of similarly strutured result objects.
    """

    def __init__(self, field_names):
        self._current_field_index = 0
        self._field_object = None
        self._field_names = field_names

    def __iter__(self):
      return self

    def __next__(self):
        if self._current_field_index == len(self._field_names):
            raise StopIteration()
        current_field_name = self._field_names[self._current_field_index]
        try:
            current_field_value = self._field_object[current_field_name]
        except KeyError:
            # the requested field did not existing in the listing object
            print(f"EEK: {current_field_name}")
            current_field_value = ''
        self._current_field_index += 1
        return current_field_value

    @property
    def distinguished_name(self):
        return self._field_object['distinguished_name']

    def set_field_object(self, field_object):
        self._field_object = field_object
        self._current_field_index = 0
        return self


class FieldObjectListing:
    """
    Wrapper to allow iteration of result object listings which arranges that
    each entry itself is wrapped such that only requested fields are returned.
    """

    def __init__(self, field_objects, field_names):
        self._entry_wrapper = FieldObjectIterator(field_names)
        self._objects_iterator = iter(field_objects)

    def __iter__(self):
        return self

    def __next__(self):
      return self._entry_wrapper.set_field_object(next(self._objects_iterator))


#data_accepted = _import_json('accepted.json')
#data_requested = _import_json('requested.json')


def list_peers_accepted(request, data=None):
    field_names = request.args.get('fields', '').split(',')

    return {
        'peers_listing': FieldObjectListing(data, field_names)
    }


def list_peers_requested(request, data=None):
    field_names = request.args.get('fields', '').split(',')

    return {
        'peers_listing': FieldObjectListing(data, field_names)
    }


RESPONDERS = {
    'GET /accepted': SimpleNamespace(**{
        'generate_args': list_peers_accepted,
        'template_name': "search_result",
    }),
    'GET /requested': SimpleNamespace(**{
        'generate_args': list_peers_requested,
        'template_name': "search_result",
    }),
}
