from .peers import RESPONDERS

ROUTES_JSON = {
    'GET /summary': {},
    'POST /new': {},
    'POST /accepted/delete': {},
    'POST /requested/accept': {},
    'POST /requested/delete': {},
}
