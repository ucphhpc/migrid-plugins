import { asObservable } from "../lib/observable.js";

const TABS_ACTIVE_CLASS = "TabsItem--active";

/**
 * @import {Observable, Observed} from '../lib/observable.mjs'
 */

class Tabs {
  /**
   *
   * @param {HTMLElement[]} elements
   * @param {Observable} selectedIndex
   */
  constructor(elements, selectedIndex) {
    this.elements = elements;
    this.handler = null;
    this._selectedIndex = selectedIndex;
  }

  get currentIndex() {
    return this._selectedIndex.value;
  }

  bind() {
    const observable = this._selectedIndex;

    const initialValue = observable.value;

    this.handler = (ev) => {
      const selectedIndex = this.elements.indexOf(ev.currentTarget);
      this.setSelectedIndex(selectedIndex);
    };
    for (const el of this.elements) {
      el.addEventListener("click", this.handler);
    }
    this.setSelectedIndex(initialValue);
    return this;
  }

  destroy() {
    for (const el of this.elements) {
      el.removeEventListener(this.boundListener);
    }
    this.boundListener = null;
  }

  setSelectedIndex(selectedIndex) {
    if (this.currentIndex !== selectedIndex) {
      this.elements[this.currentIndex].classList.remove(TABS_ACTIVE_CLASS);
      this._selectedIndex.setValue(selectedIndex);
    }
    this.elements[this.currentIndex].classList.add(TABS_ACTIVE_CLASS);
  }

  /**
   *
   * @param {HTMLElement} parent
   * @param {Observed} observed
   */
  static fromElement(parent, observed) {
    const observable = asObservable(observed);
    const elements = parent.querySelectorAll("li");
    return new Tabs(Array.from(elements), observable).bind();
  }
}

export { Tabs };
