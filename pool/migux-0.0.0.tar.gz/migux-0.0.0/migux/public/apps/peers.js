import { Tabs } from "../components/Tabs.js";
import { binder } from "../lib/binding.js";
import {
  NO_VALUE,
  anyChangeValue,
  asObservable,
  observedValue,
  computedValue,
  observedArray,
  observedHtml,
} from "../lib/observable.js";
import { createNamespacedState } from "../lib/state.js";

const _DEFINITION = Symbol("DEFINITION");

function _resOkOrThrow(res) {
  if (res.ok) return res;
  if (res.headers["content-type"] === "application/json") return res;
  const error = new Error(`HTTP ${res.status} Error`);
  error.status = res.status;
  throw error;
}

function _someTruthyValue(arrayOfValues) {
  return arrayOfValues.some((value) => !!value);
}

function _decodeStorage(namespace) {
  try {
    let defaults = JSON.parse(localStorage.getItem(namespace));
    if (defaults["__app__"] === undefined) {
      defaults = { __app__: defaults };
    }
    return defaults;
  } catch {
    return null;
  }
}

const APP_NAME = "peers";

export class PeersApp {
  constructor(state, { baseUrl, urlOptions, _fetch = fetch, ...options } = {}) {
    this.state = state;
    this._baseUrl = null;
    this._buildUrl = null;
    this._binder = null;
    this._fetch = null;
    this._options = options;
    this._urlOptions = null;
    this.__getPromise = null;

    if (!urlOptions) {
      urlOptions = {
        baseUrl: baseUrl || "",
        buildUrl: null,
      };
    } else if (!urlOptions.baseUrl) {
      urlOptions = Object.assign({}, urlOptions);
      urlOptions.baseUrl = baseUrl || "";
    }
    this._urlOptions = urlOptions;

    if (urlOptions.baseUrl.endsWith("/")) {
      urlOptions.baseUrl = urlOptions.baseUrl.slice(0, -1);
    }

    if (!urlOptions.buildUrl) {
      urlOptions.buildUrl = PeersApp.restUrl;
    }
    const buildUrl = urlOptions.buildUrl;
    this._buildUrl = (...args) => buildUrl(urlOptions, ...args);

    const processResponse = urlOptions.processResponse;
    const hasProcessResponse = typeof processResponse === "function";

    // now add a bound fetch for use by the application
    if (hasProcessResponse) {
      this._fetch = (...args) =>
        _fetch(...args)
          .then(_resOkOrThrow)
          .then(processResponse);
    } else {
      this._fetch = (...args) => _fetch(...args).then(_resOkOrThrow);
    }
  }

  get rootElement() {
    if (!this._binder) {
      throw new Error("application not bound - root element unavailable");
    } else {
      return this._binder.rootElement;
    }
  }

  bind(root) {
    this._binder = binder(root, this);
    if (typeof this.onInitialize === "function") {
      this.onInitialize();
    }
  }

  rebind(bindin, observableName) {
    this._binder.rebind(bindin, observableName);
  }

  onClose() {
    this.rootElement.parentNode.removeChild(this.rootElement);
    this._binder.destroy();
    this._binder = null;
    this.onDestroy();
  }

  onDestroy() {
    const beforeDestruction = this._options.beforeDestruction;
    if (typeof beforeDestruction === "function") {
      beforeDestruction(this);
    }
  }

  onInitialize() {
    this.summaryRequest();

    this.maybeClearListing(this.state.formState("search_accepted"));
    this.maybeClearListing(this.state.formState("peers_requested"));
  }

  request(requestPath, requestOptions, namespace) {
    const { url, ...fetchOptions } = this._buildUrl(
      requestPath,
      requestOptions,
    );

    if (this.state.isFormState(namespace)) {
      return this._fetchAndUpdateFormState(url, fetchOptions, namespace);
    } else {
      return this._fetch(url, fetchOptions);
    }
  }

  _fetchAndUpdateFormState(url, fetchOptions, formState) {
    formState.submitted(true);

    return this._fetch(url, fetchOptions)
      .then((result) => {
        formState.submitted(false);
        return result;
      })
      .catch((error) => {
        formState.submitted(false);
        throw error;
      });
  }

  summaryRequest() {
    const acceptedState = this.state.formState("search_accepted");
    const requestedState = this.state.formState("peers_requested");

    this.request("/summary", {
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then(async (res) => {
        const result = await res.json();
        if (typeof result.error === "string" && result.error) {
          const error = new Error(result.error);
          error.status = 422;
          throw error;
        }

        acceptedState.total(result.data.accepted_count);
        requestedState.total(result.data.requested_count);
      })
      .catch(() => {
        // ignore
      });
  }

  maybeClearListing(namespace) {
    const hasNoResults =
      namespace.query() === "" && namespace.results_rows().length > 0;
    if (hasNoResults) {
      namespace.count(0);
      namespace.results("");
      namespace.results_rows([]);
      namespace.results_placeholder("No results.");
    }
  }

  peersListing(endpoint, { term, includeColumns }, namespace) {
    if (term === "") {
      namespace.count(0);
      namespace.results("");
      namespace.results_rows([]);
      namespace.results_placeholder("No results.");
      return;
    }

    namespace.results("");
    namespace.results_placeholder("Searching...");

    const requestOptions = {
      query: {
        query: term,
        fields: includeColumns,
      },
    };
    return this.request(endpoint, requestOptions, namespace)
      .then(async (res) => {
        const html = await res.text();
        const { rowCount, resultRows } = namespace.results(html);
        namespace.count(rowCount);
        namespace.results_rows(resultRows);
        namespace.results_placeholder("");
        this.rebind("array", "results_rows");
      })
      .catch((error) => {
        if (error.status === 404) {
          namespace.results_placeholder("No results.");
        } else {
          namespace.results_placeholder(error.message);
        }
      });
  }

  /* search accepted functions */

  searchAcceptedColumnChange(_, namespace) {
    namespace.results("");
  }

  searchAcceptedQuery({ value: term }, namespace) {
    const includeColumns = ["email", "full_name"];

    for (const colName of PeersApp.CONST_SEARCH_ACCEPTED_COLNAMES) {
      const columnIsShown = namespace[`col_${colName}`];
      if (columnIsShown()) {
        includeColumns.push(colName);
      }
    }

    return this.peersListing("/accepted", { term, includeColumns }, namespace);
  }

  searchAcceptedSelectAll({ value: selectedValue }, namespace, element) {
    for (const item of namespace.results_rows()) {
      item.selected(selectedValue);
    }
  }

  searchAcceptedRemove(_, appNamespace) {
    const namespace = appNamespace.namespace("form__search_accepted");
    const resultsRows = namespace.results_rows();

    const distinguished_names_for_removal = [];

    for (const entry of resultsRows) {
      if (entry.selected()) {
        distinguished_names_for_removal.push(entry.peer_dn());
      }
    }

    if (distinguished_names_for_removal.length === 0) {
      // no peers were selected - nothing to do
      return;
    }

    const requestOptions = {
      method: "POST",
      data: { peers: distinguished_names_for_removal },
    };
    this.request("/accepted/delete", requestOptions)
      .then(async (res) => {
        const result = await res.json();
        if (typeof result.error === "string" && result.error) {
          const error = new Error(result.error);
          error.status = 422;
          throw error;
        }

        this.searchAcceptedQuery({ value: namespace.query() }, namespace);
      })
      .catch((err) => {
        debugger;
      });
  }

  searchAcceptedColumnCount() {
    const namespace = this.state.namespace("form__search_accepted");

    let optionalColumnCount = 0;
    for (const colName of PeersApp.CONST_SEARCH_ACCEPTED_COLNAMES) {
      const columnIsShown = namespace[`col_${colName}`];
      if (columnIsShown()) {
        optionalColumnCount += 1;
      }
    }

    return (
      1 /* checkbox */ +
      2 /* two mandatory */ +
      optionalColumnCount +
      1 /* settings */
    );
  }

  searchAcceptedToggleSettings(_, namespace, element) {
    namespace.show_toggles(!namespace.show_toggles());
  }

  searchAcceptedSettingsHide(_, namespace) {
    const wereResultsCleared = namespace.results() === "";
    if (wereResultsCleared) {
      // results are cleared when the clumn seleciton changes, implying that
      // the column selections were in fact changed and so must be refreshed
      this.searchAcceptedQuery({ value: namespace.query() }, namespace);
    }
  }

  /* search requested functions */

  searchRequestedQuery({ value: term }, namespace) {
    const includeColumns = [
      "full_name",
      "email",
      "organization",
      "kind",
      "expire",
    ];

    return this.peersListing("/requested", { term, includeColumns }, namespace);
  }

  /* new peer functions */

  newPeerCreate(ev, namespace, element) {
    const appState = this.state.namespace("__app__");
    const requestedPeerState = this.state.formState("peers_requested");
    const values = this.state.serializeNamespace(namespace);

    if (!values.state) {
      values.state = "NA";
    }

    const requestOptions = {
      method: "POST",
      data: values,
    };
    return this.request("/new", requestOptions, namespace)
      .then(async (res) => {
        const result = await res.json();
        if (typeof result.error === "string" && result.error) {
          const error = new Error(result.error);
          error.status = 422;
          throw error;
        }

        const term = requestedPeerState.query();
        await this.searchRequestedQuery({ value: term }, requestedPeerState);
        this.newPeerClear();
        appState.selected_tab_index(1);
      })
      .catch((error) => {
        namespace._error_string(error.message);
      });
  }

  newPeerClear(ev, namespace, element) {
    const newPeerNamespace = this.state.namespace("form__peers_new");
    this.state.resetNamespace(newPeerNamespace);
  }

  /* common functions */

  static definition() {
    return this[_DEFINITION];
  }

  /**
   * MiG specific response processing function - given a response, handle the
   * wrapping done by the MiG backend and hand back a response to the caller
   * that looks much closer to standard JSON endpoint.
   *
   * This function is intended to be passed as `processResponse` within the
   * urlOptions when bootstrapping an applicatin running against a MiG backend.
   */
  static async migResponse(res) {
    if (res.headers.get("content-type") !== "application/json") {
      return res;
    }

    const json = await res.json();

    let found = null;
    for (const entry of json) {
      if (entry.object_type === "objects") {
        found = entry;
        break;
      }
    }
    if (found === null) {
      throw Error("NOT_IMPLEMENTED");
    }
    const { status, ...rest } = found.objects;
    const migRes = new Response("", { status });
    migRes.json = () => {
      return Promise.resolve(rest);
    };
    return migRes;
  }

  static migUrl(baseOptions, urlPath, urlOptions) {
    const migType = baseOptions.migType;
    if (!migType) throw new Error("urlOptions.migType missing");
    const pathParts = urlPath.split("/");
    const lastPathPart = pathParts[pathParts.length - 1];

    let body;
    let endpoint;
    let headers;
    let requestData;
    if (
      (urlOptions.method === "POST" && urlOptions.data !== undefined) ||
      (urlOptions.headers || {})["Content-Type"] === "application/json"
    ) {
      const hasPayload = urlOptions.method === "POST";

      endpoint = "/datainterface.py";
      headers = {
        "Content-Type": "application/json",
      };
      body = JSON.stringify({
        ...urlOptions.data,
        type: `${baseOptions.migType}__${lastPathPart}`,
        operation: hasPayload ? "create" : "read",
      });
    } else {
      endpoint = "/tmplinterface.py";
      headers = undefined;
      const bodyObj = {
        ...urlOptions.query,
        type: `${baseOptions.migType}__${lastPathPart}`,
        operation: "read",
      };
      body = new FormData();
      for (const [k, v] of Object.entries(bodyObj)) {
        body.set(k, v);
      }
    }

    return {
      url: `${baseOptions.baseUrl}${endpoint}`,
      method: "POST",
      headers,
      body,
    };
  }

  static restUrl(baseOptions, urlPath, urlOptions) {
    if (typeof baseOptions === "string") {
      baseOptions = { baseUrl: baseOptions };
    }
    if (!urlOptions) urlOptions = {};
    if (!urlOptions.method) urlOptions.method = "GET";

    const baseUrl = baseOptions.baseUrl;
    const queryString = new URLSearchParams(urlOptions.query || {}).toString();
    const url = `${baseUrl}${urlPath}${queryString ? "?" : ""}${queryString}`;

    let extraOptions;
    if (
      (urlOptions.method === "POST" && urlOptions.data !== undefined) ||
      (urlOptions.headers || {})["Content-Type"] === "application/json"
    ) {
      extraOptions = {
        headers: {
          "Content-Type": "application/json",
        },
        body: urlOptions.data ? JSON.stringify(urlOptions.data) : undefined,
      };
    } else {
      extraOptions = undefined;
    }

    return { url, method: urlOptions.method, ...extraOptions };
  }
}

PeersApp.CONST_SEARCH_ACCEPTED_COLNAMES = [
  "organization",
  "country",
  "state",
  "kind",
  "label",
  "expire",
];

PeersApp.CONST_SEARCH_REQUESTED_COLNAMES = ["organization", "country", "state"];

export const App = PeersApp;

(function () {
  function makePeersListingState() {
    return {
      query: "",
      results: observedHtml(NO_VALUE, {
        select: "tbody",
        decodeHtml: (subtreeEl) => {
          const rowEls = Array.from(subtreeEl.querySelectorAll("tr"));
          const rowCount = rowEls.length;

          if (rowCount === 1 && rowEls[0].classList.contains("__ignore__")) {
            return { rowCount: 0, resultRows: NO_VALUE };
          }

          const resultRows = rowEls.map((rowEl) => {
            return {
              selected: rowEl.querySelector('input[type="checkbox"]').checked,
            };
          });

          return { rowCount, resultRows };
        },
      }),
      results_rows: observedArray(NO_VALUE, {
        definition: {
          peer_dn: NO_VALUE,
          selected: false,
        },
      }),
      results_placeholder: observedHtml(NO_VALUE),
    };
  }

  PeersApp[_DEFINITION] = {
    __app__: {
      disable_close: (state) => {
        const observing = new Set();
        for (const [, formNamespace] of Object.entries(state.forms)) {
          observing.add(formNamespace.submitted);
        }
        return computedValue(_someTruthyValue, observing);
      },
      selected_tab_index: 0,
    },
    forms: {
      search_accepted: {
        ...makePeersListingState(),
        all: false,
        count: 0,
        total: 0,
        show_toggles: false,
        // columns to show
        col_organization: true,
        col_country: false,
        col_state: false,
        col_kind: true,
        col_label: true,
        col_expire: true,
        changed_column: (state, namespace) => {
          return anyChangeValue([
            namespace.col_organization,
            namespace.col_country,
            namespace.col_state,
            namespace.col_kind,
            namespace.col_label,
            namespace.col_expire,
          ]);
        },
      },
      peers_requested: {
        ...makePeersListingState(),
        count: 0,
        total: 0,
      },
      peers_new: {
        full_name: "",
        email: "",
        label: "",
        expire: "",
        organization: "",
        kind: NO_VALUE,
        country: NO_VALUE,
        state: NO_VALUE,
        invite_on_email: true,
        _error_string: "",
      },
      peers_import: {},
    },
  };
})();

export function bootstrap(root, options) {
  const definition = PeersApp.definition();
  const state = createNamespacedState(
    definition,
    _decodeStorage(`migapp-${APP_NAME}`),
  );
  const app = new PeersApp(state, {
    ...options,
    beforeDestruction: (app) => {
      const item = JSON.stringify(app.state.serialize());
      localStorage.setItem(`migapp-${APP_NAME}`, item);
    },
  });

  const tabElement = root.querySelector('#peers-modal [role="tablist"]');
  Tabs.fromElement(tabElement, state.selected_tab_index);

  const elements = root.querySelectorAll('#peers-modal [role="tabpanel"]');
  const observable = asObservable(state.selected_tab_index);
  observable.addEventListener("change", (ev) => {
    const detail = ev.detail;
    const { value, previousValue } = detail;

    if (value !== previousValue) {
      elements[previousValue].classList.remove("active");
    }
    elements[value].classList.add("active");
  });

  app.bind(root);

  return app;
}

(() => {
  if (typeof window === "undefined") {
    return;
  }

  window.MiG = window.MiG || {};
  window.MiG.applications = window.MiG.applications || {};
  const applications = window.MiG.applications;

  const app = (applications["peers"] = applications["peers"] || {
    bootstrap: null,
    instance: null,
  });
  app.bootstrap = (root, options) => (app.instance = bootstrap(root, options));
  window.addEventListener("beforeunload", () => app.instance.onDestroy());
})();
