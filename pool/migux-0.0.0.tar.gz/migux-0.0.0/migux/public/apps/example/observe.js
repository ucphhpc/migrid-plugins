import { binder } from "../../lib/binding.js";
import { observedValue } from "../../lib/observable.js";
import { createState } from "../../lib/state.js";

const APP_NAME = "example/observe";

export function bootstrap(root) {
  const definition = {
    who: observedValue("someone"),
  };
  const state = createState(definition);

  binder(root, state);
}

(() => {
  window.MiG = window.MiG || {};
  window.MiG.applications = window.MiG.applications || {};
  const applications = window.MiG.applications;

  const app = (applications[APP_NAME] = applications[APP_NAME] || {
    bootstrap: null,
    instance: null,
  });
  app.bootstrap = () => (app.instance = bootstrap(document));

  window.addEventListener("beforeunload", app.onbeforeunload);
})();
