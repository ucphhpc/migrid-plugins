# migrid-ux

This repository contains a series of small isolated web applications which
together comprise various portions of functionality within the Migrid user
interface, as well as the support libraries that underpin them. The repository
acts as a supporting project providing enough "surroundings" enough to allow
their use and development in isolation.

## Basic principles

The application are structured to have a clean separation between their state
and their rendered representation. The "data" backing an application, which we
refer to as their [state](#state), is _bound_ (see [binding](#binding)) to a
the on-screen HTML markup.

### Handling of state

The state is represented as a series of observed values which signal when they
are changed. Such values is commonly referred to as [observables](#observable).
These values are grouped into [namespaces](#namespace) of related values, each
of which can be individually serialised on demand.

## Supporting modules

### lib/binding.mjs

This is responsible for wiring HTML markup to observables present in the state.

### lib/observable.mjs

Provides the basic observed value primitives.

### lib/state.mjs

Exposes both a type and a number of construction functions which can generate
and manage the observable values for a particular application based upon the
delcarative definition of required values specified by a given application.

## Usage

The repository is arranged to be consistent with migrid-sync and as such the
main functions are exposed via a Makefile at the top level. A basic bringup
involves running:

```sh
$ make local
```

Running the above will have the effect of installing and necessary dependencies
for local development and provisioning a virtual environment to allow the use
of a fake backend intended to support rapid iteration ruding development. As
a final step a local web server and local backend will be started, with the
application then being accessible at: `http://localhost:8880`

## Glossary

### binding

The process of attaching DOM elements to their respective observables.

### namespace

A grouping of observable values which are considered to be related.

### observable

An embellished value able to signal interested parties when it is changed.

### state

The complete set of observed values that represent an active application.
